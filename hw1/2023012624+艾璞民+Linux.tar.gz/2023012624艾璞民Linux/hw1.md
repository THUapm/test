# 分析报告
## 1. SL 程序输出
SL 截图如下：![alt text](image.png)
## 2. grep指令
指令及输出结果如下：![alt text](image-1.png)
## 3. example.sh输出
先用chmod指令将example.sh变为可执行文件
再在命令行中输入example.sh即可得到输出结果
输出结果如下：![alt text](image-2.png)
![alt text](image-3.png)
## 4. 超级用户权限
命令行中的指令与输出结果如图：
![alt text](image-4.png)



这张图是输入密码显示星号的图片，第一张没有截到
![alt text](image-5.png)